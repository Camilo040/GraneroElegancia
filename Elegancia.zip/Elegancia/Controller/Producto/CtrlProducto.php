<?php

include_once '../DAO/ProductoDAO.php';

class CtrlProducto extends ProductoDAO{

    public function read() {
        include_once '../View/Producto/ModalsProducto.php';
        include_once '../View/Producto/ViewProducto.php';
        
        ViewProducto::getRead();
    }
     public function data(){
        $listProducto=[];
        $array=[];
        $listProducto=ProductoDAO::getAll(); //donde sale la extraccion.
        foreach($listProducto as $key => $rowProducto){          
           
            $array['data'][$key]['pro_id'] = $rowProducto['pro_id'];               
            $array['data'][$key]['pro_nombre'] = $rowProducto['pro_nombre'];       
            $array['data'][$key]['pro_precio'] = $rowProducto['pro_precio'];
            $array['data'][$key]['pro_estado'] = $rowProducto['pro_estado'];
            $array['data'][$key]['buttons']  = '<ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarProducto" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-edit fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarProducto">
                        <li><a class="dropdown-item btnShowEdit" href="#!" data-bs-toggle="modal" data-bs-target="#modalEditProducto" data-url="'.getUrl('Producto', 'Producto', 'getData', array('id' => $rowProducto['pro_id']), 'ajax').'" role="button">Editar</a></li>
                        <li><hr class="dropdown-divider" /></li>
                        <li><a class="dropdown-item" href="#!">Eliminar</a></li>                                              
                    </ul>
                </li>
            </ul>';                  
        };
       
        /*
            json_encode($array) => se convierte el arreglo a formato JSON para la libreria data table
        */
        echo json_encode($array);
    }
    public function postNew()
    {
        $pro_nombre = $_POST['pro_nombre'];  
        $pro_precio = $_POST['pro_precio']; 
        $pro_estado = $_POST['pro_estado'];     
        $rs = ProductoDAO::getInstance()->add($pro_nombre,$pro_precio,$pro_estado);
        if ($rs == 1) {          
            // Redirecciona con mensaje de éxito
            messageSweetAlert("¡Éxito!", "Producto creado correctamente.", "success", "#4CAF50", getUrl('Producto', 'Producto', 'read'));           
        } else {
            // Redirecciona con mensaje de error
            messageSweetAlert("Advertencia!", "No fue posible crear el Producto", "warning", "#f7060d", getUrl('Producto', 'Producto', 'read')); 
        }
    }
    public function getData(){
        $pro_id = $_GET['id'];
        $array = [];
        $rs = ProductoDAO::getInstance()->findById($pro_id);
        foreach($rs as $key => $rowProducto){          
            $array['pro_id'] = $rowProducto['pro_id'];          
            $array['pro_nombre'] = $rowProducto['pro_nombre'];    
            $array['pro_precio'] = $rowProducto['pro_precio'];  
            $array['pro_estado'] = $rowProducto['pro_estado'];  
        }        
        echo json_encode($array);
    }
    public function postUpdate(){
        $pro_id=$_POST['idProductoEdit'];
        $pro_nombre=$_POST['nombreProductoEdit'];
        $pro_precio=$_POST['precioProductoEdit'];
        $pro_estado=$_POST['estadoProductoEdit'];
        $rs=ProductoDAO::getInstance()->update($pro_id, $pro_nombre, $pro_precio, $pro_estado);
        if ($rs == 1) {          
            // Redirecciona con mensaje de éxito
            messageSweetAlert("¡Éxito!", "Producto actualizado correctamente.", "success", "#4CAF50", getUrl('Producto', 'Producto', 'read'));          
        } else {
            // Redirecciona con mensaje de error
            messageSweetAlert("Advertencia!", "No fue posible actualizar el Producto", "warning", "#f7060d", getUrl('Producto', 'Producto', 'read'));
        }
    }
}