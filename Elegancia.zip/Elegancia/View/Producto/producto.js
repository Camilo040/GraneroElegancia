$(document).ready(function () {
    listProducto();
});
var listProducto = function () {
    var table = $('#dt_producto').DataTable({
        dom: "Bfrtip",
        buttons: [
            {
                extend: 'excel',
                footer: true,
                title: "Lista de Detalles de factura",
                filename: "listProducto",
                text: '<button class="btn btn-success">Exportar a Excel</button>'
            },
        ],
        destroy: true,
        searching: true,
        orderable: false,
        lengthChange: false,
        pageLength: 15,
        autoWidth: true,
        "ajax": {
            "url": "ajax.php?module=Producto&controller=Producto&function=data",
            "method": "post"
        },
        "deferRender": true,

        "columns": [
            {"data": "pro_id"},
            {"data": "pro_nombre"},
            {"data": "pro_precio"},
            {"data": "pro_estado"},
            {"data": "buttons"}
        ]
    });
showModalsProducto("#dt_producto tbody", table);

}
var showModalsProducto = function (tbody, table) {
    $(tbody).on("click", ".btnShowEdit", function () {
        var url = $(this).attr("data-url");
        $.ajax({
            url: url,
            dataType: "JSON",
            success: function (rs) {
                console.log(rs);
                $("#idProductoEdit").val(rs.pro_id);
                $("#nombreProductoEdit").val(rs.pro_nombre);
                $("#precioProductoEdit").val(rs.pro_precio);
                $("#estadoProductoEdit").val(rs.pro_estado);
            },
        });
    });
    $(tbody).on("click", "#btnDelete", function () {
    });
};