<?php

class ModalsProducto {

    public static function modalCreate() {
        ?>
        <div class="modal" tabindex="-1"  id="modalCreateProducto">
            <div class="modal-dialog modal-xs">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Registro Productos</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form name="frmCreateProducto" action="<?php echo getUrl('Producto', 'Producto', 'postNew'); ?>" method="post">
                            <div class="mb-3">
                                <input type="hidden" name="idUsuario" id="idUsuario" class="form-control" require><br>
                            </div>
                            <div class="mb-3">
                                <label for="nombre" class="from-label">Producto</label><br>
                                <input type="text" name="pro_nombre" id="pro_nombre" class="form-control" require>
                            </div>
                            <div class="mb-3">
                                <label for="nombre" class="from-label">Precio</label><br>
                                <input type="text" name="pro_precio" id="pro_precio" class="form-control" require>
                            </div>
                            <div class="mb-3">
                                <label for="nombre" class="from-label">Estado</label><br>
                                <input type="text" name="pro_estado" id="pro_estado" class="form-control" require>
                            </div>    
                            
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
        <?php
    }
    public static function modalEdit(){
      ?>
<div class="modal" tabindex="-1"  id="modalEditProducto">
<div class="modal-dialog modal-xs">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title">Editar Producto</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
<form name="frmUpdateProducto" action="<?php echo getUrl('Producto','Producto','postUpdate');?>" method="post">
<div class="mb-3">
<label for="codigo" class="from-label">ID</label><br>
<input type="number" name="idProductoEdit" id="idProductoEdit" class="form-control" require readonly><br>
</div>
<div class="mb-3">
<label for="nombre" class="from-label">nombre</label><br>
<input type="text" name="nombreProductoEdit" id="nombreProductoEdit" class="form-control" require>
</div>
<div class="mb-3">
<label for="nombre" class="from-label">precio</label><br>
<input type="text" name="precioProductoEdit" id="precioProductoEdit" class="form-control" require>
</div>
<div class="mb-3">
<label for="nombre" class="from-label">estado</label><br>
<input type="text" name="estadoProductoEdit" id="estadoProductoEdit" class="form-control" require>
</div>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
<button type="submit" class="btn btn-primary">Save changes</button>
</div>
</form>
</div>
</div>
</div>
<?php
  }    

}
