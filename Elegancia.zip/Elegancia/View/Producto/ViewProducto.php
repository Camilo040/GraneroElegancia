<?php

class ViewProducto {

    public static function getRead() {
        ?>
        <div class="container-fluid px-4">
            <h1 class="mt-4">Productos</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Listar</li>
            </ol>
            <div class="row">

                <div class ="lg-6 md-2 xs-12">

                    <div class="col-md-1">
                        <div class="card shadow-sm border-success">
                            <div class="card-body text-center">
                                <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modalCreateProducto">CREAR</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="table-responsive">
                    <table id="dt_producto" class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>PRODUCTO</th>
                                <th>PRECIO</th>
                                <th>ESTADO</th>   
                                <th>BOTONES</th>                                                                     
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>

        <?php
        ModalsProducto::modalCreate();
        ModalsProducto::modalEdit();
    }
}
?> 
<script type="text/javascript" src="../View/Producto/Producto.js"></script>