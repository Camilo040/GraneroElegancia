<?php

class ModalsDfactura {

    public static function modalCreate() {
        ?>
        <div class="modal" tabindex="-1"  id="modalCreateFactura">
            <div class="modal-dialog modal-xs">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Registro Dfactura</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form name="frmCreateFactura" action="<?php echo getUrl('DFactura', 'DFactura', 'postNew'); ?>" method="post">
                            <div class="mb-3">
                                <input type="hidden" name="idUsuario" id="idUsuario" class="form-control" require><br>
                            </div>
                            <div class="mb-3">
                                <label for="nombre" class="from-label">Factura fecha DB</label><br>
                                <input type="date" name="fact_fechaDB" id="fact_fechaDB" class="form-control" require>
                            </div>
                            <div class="mb-3">
                                <label for="nombre" class="from-label">Factura fecha</label><br>
                                <input type="date" name="fact_fecha" id="fact_fecha" class="form-control" require>
                            </div>
                            <div class="mb-3">
                                <label for="nombre" class="from-label">Cliente</label><br>
                                <input type="text" name="cli_nit" id="cli_nit" class="form-control" require>
                            </div>    
                            <div class="mb-3">
                                <label for="nombre" class="from-label">Total</label><br>
                                <input type="text" name="fact_total" id="fact_total" class="form-control" require>
                            </div>  
                            
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
        <?php
    }
}
