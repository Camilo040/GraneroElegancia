$(document).ready(function () {
    listDfactura();
});
var listDfactura = function () {
    var table = $('#dt_dfactura').DataTable({
        dom: "Bfrtip",
        buttons: [
            {
                extend: 'excel',
                footer: true,
                title: "Lista de Detalles de factura",
                filename: "listDfactura",
                text: '<button class="btn btn-success">Exportar a Excel</button>'
            },
        ],
        destroy: true,
        searching: true,
        orderable: false,
        lengthChange: false,
        pageLength: 15,
        autoWidth: true,
        "ajax": {
            "url": "ajax.php?module=Dfactura&controller=Dfactura&function=data",
            "method": "post"
        },
        "deferRender": true,

        "columns": [
            {"data": "fact_id"},
            {"data": "fact_fechaDB"},
            {"data": "fact_fecha"},
            {"data": "cli_nit"},
            {"data": "fact_total"},
            {"data": "buttons"}
        ]
    });
    showModalsDfactura("#dt_dfactura tbody", table);
}

var showModalsDfactura = function (tbody, table) {

    $(tbody).on("click", "#btnDelete", function () {
    });
};