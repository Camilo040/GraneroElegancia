<?php		    
    
    $servidor="127.0.0.1";
    $usuario="root";
    $clave="";
    $puerto=33066;
    $baseDatos="bd_granero";  

?>