<?php
declare(strict_types=1);

use PHPUnit\Framework\TestCase;

/**
 * Pruebas básicas para la clase DAO de usuario.
 * Ajusta los nombres de clases y rutas si son distintos a los reales.
 */
final class UsuarioDaoTest extends TestCase
{
    protected function setUp(): void
    {
        // Preparación: si tu DAO usa PDO, aquí podrías crear una BD SQLite ':memory:'.
    }

    public function testClaseExiste(): void
    {
        $this->assertTrue(class_exists(\Elegancia\DAO\UsuarioDAO::class) || class_exists('UsuarioDAO'), "La clase UsuarioDAO debe existir.");
    }

    public function testMetodosBasicosPresentes(): void
    {
        $class = class_exists(\Elegancia\DAO\UsuarioDAO::class) ? \Elegancia\DAO\UsuarioDAO::class : 'UsuarioDAO';
        $this->assertTrue(method_exists($class, 'getALL') || method_exists($class, 'getAll'), "Debe existir el método getALL/getAll.");
        $this->assertTrue(method_exists($class, 'save') || method_exists($class, 'insert'), "Debe existir un método para insertar/guardar.");
    }

    // Ejemplo: prueba que utiliza una DB SQLite en memoria
    public function testGetAllRetornaArray(): void
    {
        // Si tu DAO acepta un PDO, instáncialo y pásalo; si no, adapta la prueba.
        if (!class_exists('PDO')) {
            $this->markTestSkipped('PDO no está disponible en este entorno de test.');
        }

        // ejemplo hipotético — adapta según constructor real de UsuarioDAO
        try {
            $pdo = new PDO('sqlite::memory:');
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            // crear tabla mínima usada por UsuarioDAO (ajusta columnas)
            $pdo->exec('CREATE TABLE usuario (usu_id INTEGER PRIMARY KEY, usu_nombre TEXT);');
            $pdo->exec("INSERT INTO usuario (usu_nombre) VALUES ('prueba');");

            // Si la clase tiene constructor que recibe PDO:
            if (class_exists(\Elegancia\DAO\UsuarioDAO::class) && (new ReflectionClass(\Elegancia\DAO\UsuarioDAO::class))->hasMethod('__construct')) {
                $dao = new \Elegancia\DAO\UsuarioDAO($pdo);
                $result = $dao->getALL();
                $this->assertIsArray($result);
            } else {
                $this->markTestIncomplete('Adaptar testGetAllRetornaArray al constructor real de UsuarioDAO.');
            }
        } catch (Exception $e) {
            $this->fail('Falla en setup PDO: ' . $e->getMessage());
        }
    }
}