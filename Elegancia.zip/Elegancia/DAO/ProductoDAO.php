<?php

include_once '../Lib/Config/conexionSqli.php';

class ProductoDAO extends Connection {

    private static $instance = NULL;

    public static function getInstance() {
        if (self::$instance == NULL)
            self::$instance = new ProductoDAO();
        return self::$instance;
    }

    public function getAll($status = "") {
        $condicion = "";
        if ($status != "") {
            $condicion = " where cli_estado = '" . $status . "'";
        }
        $sql = "SELECT * FROM producto " . $condicion;
        $result = $this->execute($sql);
        return $result;
    }

    public function findById($pro_id) {
        try {
            $sql = "SELECT * FROM producto WHERE pro_id = '".$pro_id."'";
            $result = $this->execute($sql);
            return $result;
        } catch (PDOException $exc) {
            die('Error findById() ProductoDAO:<br/>' . $exc->getMessage());
            $rs = 0;
        }
    }
    public function add($pro_nombre,$pro_precio, $pro_estado){
        $rs="";
        try {
            $sql = "insert into producto(pro_nombre,pro_precio,pro_estado) values ('".$pro_nombre."','".$pro_precio."','".$pro_estado."')";
            $result = $this->execute($sql);
            $rs=1;
        }catch (PDOException $exc) {
            die('Error Add() ProductoDAO:<br/>' . $exc->getMessage());
            $rs=0;
        }
        return $rs;
    }
    public function update($pro_id,$pro_nombre,$pro_precio, $pro_estado){
        $rs="";
        try {
            $sql = "update producto set pro_nombre ='".$pro_nombre."', pro_precio ='".$pro_precio."', pro_estado ='".$pro_estado."'  where  pro_id ='".$pro_id."'";
            $result = $this->execute($sql);
            $rs=1;
        }catch (PDOException $exc) {
            die('Error update() ProductoDAO:<br/>' . $exc->getMessage());
            $rs=0;
        }
        return $rs;
    }
}
