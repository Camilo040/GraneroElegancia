<?php

include_once '../lib/Config/conexionSqli.php';

class DfacturaDAO extends Connection {
    //put your code here
     private static $instance = NULL;
    public static function getInstance(){
        if(self::$instance == NULL)
            self::$instance = new DfacturaDAO();
        return self::$instance;
    }
     public function getALL(){
        $sql = "SELECT 	fact_id,fact_fechaDB,fact_fecha,cli_nit,fact_total FROM factura";
        $result = $this->execute($sql);
       
        return $result;
    }
    public function add($fact_fechaDB,$fact_fecha,$cli_nit,$fact_total){
        $rs="";
        try {
            $sql = "insert into factura(fact_fechaDB,fact_fecha,cli_nit,fact_total) values ('".$fact_fechaDB."','".$fact_fecha."','".$cli_nit."','".$fact_total."')";
            $result = $this->execute($sql);
            $rs=1;
        }catch (PDOException $exc) {
            die('Error Add() DfacturaDAO:<br/>' . $exc->getMessage());
            $rs=0;
        }
        return $rs;
    }
}